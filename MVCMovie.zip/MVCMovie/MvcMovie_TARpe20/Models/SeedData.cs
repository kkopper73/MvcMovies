﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MvcMovie_TARpe20.Data;
using MvcMovie_TARpe20.Models;
using System;
using System.Linq;

namespace MvcMovie_TARpe20
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new MvcMovie_TARpe20Context(
                serviceProvider.GetRequiredService<
                    DbContextOptions<MvcMovie_TARpe20Context>>()))
            {
                // Look for any movies.
                if (!context.Movie.Any())
                {

                    AddMovies(context);   // DB has been seeded
                }
                context.SaveChanges();

                if (!context.Actor.Any())
                {
                    AddActors(context);
                }

                context.SaveChanges();


            }
            
        }

        private static void AddMovies(MvcMovie_TARpe20Context context)
        {
            context.Movie.AddRange(
                 new Movie
                 {
                     Title = "The Heirs",
                     ReleaseDate = DateTime.Parse("2014-2-12"),
                     Genre = "Romantic Comedy",
                     Rating = "R",
                     Price = 7.99M
                 },

                 new Movie
                 {
                     Title = "Twilight ",
                     ReleaseDate = DateTime.Parse("2008-3-13"),
                     Genre = "Romace",
                     Rating = "E",
                     Price = 8.99M
                 },

                 new Movie
                 {
                     Title = "Doom At your Service",
                     ReleaseDate = DateTime.Parse("2021-2-23"),
                     Genre = " Romantic Comedy",
                     Rating = "PG",
                     Price = 9.99M

                 },

                 new Movie
                 {
                     Title = "Rio 2",
                     ReleaseDate = DateTime.Parse("2016-4-15"),
                     Genre = "Family",
                     Rating = "R",
                     Price = 3.99M
                 }

             );

        }

        public static void AddActors(MvcMovie_TARpe20Context context)
        {
            context.Actor.AddRange(
                  new Actor
                  {
                      FirstName = "Brown",
                      LastName = "Young",
                      DateOfBirth = DateTime.Parse("1999-7-9"),
                      NumberOfOscars = 6,
                      BirthPlace = "London",
                      NetWorth = 400000000


                  },

                  new Actor
                  {
                      FirstName = "Jungkook",
                      LastName = "Jeon",
                      DateOfBirth = DateTime.Parse("1999-6-9"),
                      NumberOfOscars = 3,
                      BirthPlace = "South-Korea",
                      NetWorth = 150000000

                  },


                  new Actor
                  {
                      FirstName = "Jonny",
                      LastName = "Kim",
                      DateOfBirth = DateTime.Parse("1995-7-19"),
                      NumberOfOscars = 1,
                      BirthPlace = "London",
                      NetWorth = 40000000
                  },

                  new Actor
                  {
                      FirstName = "Jennie",
                      LastName = "Kim",
                      DateOfBirth = DateTime.Parse("1997-8-26"),
                      NumberOfOscars = 0,
                      BirthPlace = "New York",
                      NetWorth = 90000000
                  }
               );




        }
    }



    }



    
